const WEATHER_API_KEY = 'YOUR_API_KEY'; // Replace with actual API key
const WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5';

export async function getWeather(lat: number, lon: number) {
  const response = await fetch(
    `${WEATHER_API_URL}/weather?lat=${lat}&lon=${lon}&appid=${WEATHER_API_KEY}&units=metric`
  );
  if (!response.ok) throw new Error('Failed to fetch weather data');
  return response.json();
}

export async function getCurrentLocation(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported'));
    }
    navigator.geolocation.getCurrentPosition(resolve, reject);
  });
}