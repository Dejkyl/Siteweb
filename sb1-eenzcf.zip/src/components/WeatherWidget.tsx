import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { getCurrentLocation, getWeather } from '@/lib/weather';
import { Cloud, Loader2 } from 'lucide-react';

export function WeatherWidget() {
  const { data: weather, isLoading } = useQuery({
    queryKey: ['weather'],
    queryFn: async () => {
      const position = await getCurrentLocation();
      return getWeather(position.coords.latitude, position.coords.longitude);
    },
    refetchInterval: 1800000, // 30 minutes
  });

  if (isLoading) {
    return (
      <Card className="p-4 flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </Card>
    );
  }

  if (!weather) return null;

  return (
    <Card className="p-4">
      <div className="flex items-center space-x-4">
        <Cloud className="h-8 w-8 text-blue-500" />
        <div>
          <h3 className="font-semibold">{Math.round(weather.main.temp)}°C</h3>
          <p className="text-sm text-gray-500">{weather.weather[0].description}</p>
        </div>
      </div>
    </Card>
  );
}