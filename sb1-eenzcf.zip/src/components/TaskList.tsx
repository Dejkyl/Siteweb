import { Task } from '@/types';
import { format } from 'date-fns';
import { AlertCircle, CheckCircle2, Circle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { TaskForm } from './TaskForm';
import { useTaskStore } from '@/lib/store';

const statusIcons = {
  pending: Circle,
  'in-progress': AlertCircle,
  completed: CheckCircle2,
};

const statusColors = {
  pending: 'text-gray-500',
  'in-progress': 'text-blue-500',
  completed: 'text-green-500',
};

const priorityColors = {
  low: 'bg-gray-500',
  medium: 'bg-yellow-500',
  high: 'bg-red-500',
};

interface TaskListProps {
  tasks: Task[];
}

export function TaskList({ tasks }: TaskListProps) {
  const deleteTask = useTaskStore((state) => state.deleteTask);

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {tasks.map((task) => {
        const StatusIcon = statusIcons[task.status];

        return (
          <Card key={task.id} className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-2">
                <StatusIcon
                  className={`h-5 w-5 mt-1 ${statusColors[task.status]}`}
                />
                <div>
                  <h3 className="font-semibold">{task.title}</h3>
                  {task.description && (
                    <p className="text-sm text-gray-500 mt-1">
                      {task.description}
                    </p>
                  )}
                </div>
              </div>
              <Badge className={priorityColors[task.priority]}>
                {task.priority}
              </Badge>
            </div>

            {task.dueDate && (
              <p className="text-sm text-gray-500 mt-2">
                Due: {format(new Date(task.dueDate), 'PP')}
              </p>
            )}

            <div className="flex justify-end space-x-2 mt-4">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    Edit
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Edit Task</DialogTitle>
                  </DialogHeader>
                  <TaskForm task={task} />
                </DialogContent>
              </Dialog>

              <Button
                variant="destructive"
                size="sm"
                onClick={() => deleteTask(task.id)}
              >
                Delete
              </Button>
            </div>
          </Card>
        );
      })}
    </div>
  );
}