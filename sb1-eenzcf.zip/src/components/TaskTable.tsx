import { Task } from '@/types';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { TaskForm } from './TaskForm';
import { useTaskStore } from '@/lib/store';

const statusColors = {
  'not-started': 'bg-gray-500',
  'in-progress': 'bg-blue-500',
  'completed': 'bg-green-500',
};

const priorityColors = {
  low: 'bg-gray-500',
  medium: 'bg-yellow-500',
  high: 'bg-red-500',
};

const weatherIcons = {
  sun: '☀️',
  'partly-cloudy': '⛅',
  cloudy: '☁️',
  storm: '⚡',
};

interface TaskTableProps {
  tasks: Task[];
}

export function TaskTable({ tasks }: TaskTableProps) {
  const updateTask = useTaskStore((state) => state.updateTask);
  const deleteTask = useTaskStore((state) => state.deleteTask);

  const handleProgressChange = (taskId: string, progress: number[]) => {
    updateTask(taskId, { progress: progress[0] });
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Task Name</TableHead>
            <TableHead>Assigned To</TableHead>
            <TableHead>Due Date</TableHead>
            <TableHead>Progress</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Priority</TableHead>
            <TableHead>Weather</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tasks.map((task) => (
            <TableRow key={task.id}>
              <TableCell className="font-medium">{task.title}</TableCell>
              <TableCell>{task.assignedTo || '-'}</TableCell>
              <TableCell>
                {task.dueDate
                  ? format(new Date(task.dueDate), 'PP')
                  : '-'}
              </TableCell>
              <TableCell>
                <Slider
                  value={[task.progress]}
                  onValueChange={(value) => handleProgressChange(task.id, value)}
                  max={100}
                  step={1}
                  className="w-24"
                />
                <span className="ml-2">{task.progress}%</span>
              </TableCell>
              <TableCell>
                <Badge className={statusColors[task.status]}>
                  {task.status}
                </Badge>
              </TableCell>
              <TableCell>
                <Badge className={priorityColors[task.priority]}>
                  {task.priority}
                </Badge>
              </TableCell>
              <TableCell>
                <span className="text-xl">
                  {weatherIcons[task.weatherStatus]}
                </span>
              </TableCell>
              <TableCell className="max-w-[200px] truncate">
                {task.description || '-'}
              </TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Task</DialogTitle>
                      </DialogHeader>
                      <TaskForm task={task} />
                    </DialogContent>
                  </Dialog>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => deleteTask(task.id)}
                  >
                    Delete
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}