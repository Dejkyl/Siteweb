export type TaskStatus = 'not-started' | 'in-progress' | 'completed';
export type TaskPriority = 'low' | 'medium' | 'high';
export type WeatherStatus = 'sun' | 'partly-cloudy' | 'cloudy' | 'storm';

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate?: string;
  createdAt: string;
  assignedTo?: string;
  progress: number;
  weatherStatus: WeatherStatus;
}